---
title: "Red Pepper Miso Wings"
date: 2018-12-26T12:28:47+06:00
image: images/blog/blog-img-3.jpg
description: "this is meta description"
type: "post"
---

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro modi delectus rerum, sed blanditiis eaque eum, ex et officia veritatis id hic. Deleniti eos ipsum, nihil ex id ipsa porro, accusantium, accusamus dignissimos harum, veniam culpa. Voluptate doloremque aspernatur neque vero tenetur numquam expedita ratione, sed, error exercitationem officia voluptatum molestiae quod impedit facilis, dolores laudantium quae rem! Rem obcaecati eum pariatur error quasi consequuntur repellendus aliquam vero perferendis, praesentium. Quas nulla, quae tempore omnis facere reiciendis, voluptatibus illum nemo consequuntur, magni voluptas doloremque eveniet quasi soluta porro sit cum? Alias a rerum natus, repellendus voluptas libero! Deleniti aut, sunt.
